# 🏢 OfficeHub Dashboard

A minimalist, self-hosted productivity dashboard that centralizes your office web applications into a single, elegant interface. Built as a PWA for seamless access across Windows, Android, and iOS.

![Node.js](https://img.shields.io/badge/Node.js-18+-339933?logo=node.js&logoColor=white)
![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-06B6D4?logo=tailwindcss&logoColor=white)
![PWA](https://img.shields.io/badge/PWA-Installable-5A0FC8?logo=pwa&logoColor=white)

---

## ✨ Features

- **Bento Grid Layout** — Clean, responsive card-based dashboard
- **Auto-Discovery** — Paste a URL and the app automatically fetches the name and favicon
- **Admin Mode** — Toggle to add, edit, or remove applications
- **PWA Support** — Install on any device via "Add to Home Screen"
- **Local Network** — Access from any device on your network (mobile, tablet, desktop)
- **Glassmorphism UI** — Subtle, high-end minimalist design inspired by [caioreix.com](https://caioreix.com)
- **Micro-Animations** — Fluid interactions powered by Framer Motion

---

## 🛠 Tech Stack

| Layer      | Technology                          |
|------------|-------------------------------------|
| Frontend   | React (Vite), Tailwind CSS, Framer Motion, Lucide React |
| Backend    | Node.js, Express                    |
| Database   | JSON file (`apps.json`)             |
| Distribution | Progressive Web App (PWA)         |

---

## 🚀 Quick Start

### Prerequisites

- [Node.js](https://nodejs.org/) 18+
- npm 9+

### Installation

```bash
# Clone the repository
git clone https://github.com/Theus226File/officehub-dashboard.git
cd officehub-dashboard

# Install dependencies
npm install

# Start development (server + client)
npm run dev
```

The app will be available at:

| Endpoint | URL |
|----------|-----|
| Client   | `http://localhost:5173` |
| API      | `http://localhost:3001` |
| Network  | `http://<your-local-ip>:5173` |

### Production Build

```bash
npm run build
npm start
```

---

## 📁 Project Structure

```
officehub-dashboard/
├── client/                # React frontend (Vite)
│   ├── public/            # PWA manifest, service worker, icons
│   └── src/
│       ├── components/    # Reusable UI components
│       ├── hooks/         # Custom React hooks
│       ├── services/      # API client
│       └── types/         # TypeScript interfaces
├── server/                # Express backend
│   └── src/
│       ├── controllers/   # Route handlers
│       ├── middleware/     # Validation & security
│       ├── models/        # Data persistence
│       ├── routes/        # API route definitions
│       └── services/      # Business logic
├── shared/                # Shared types between client & server
└── package.json           # Workspace root
```

---

## 📡 API Endpoints

| Method   | Endpoint         | Description              |
|----------|------------------|--------------------------|
| `GET`    | `/api/apps`      | List all applications    |
| `GET`    | `/api/apps/:id`  | Get a single application |
| `POST`   | `/api/apps`      | Add a new application    |
| `PUT`    | `/api/apps/:id`  | Update an application    |
| `DELETE` | `/api/apps/:id`  | Remove an application    |
| `GET`    | `/api/health`    | Health check             |

### Adding an app

```bash
curl -X POST http://localhost:3001/api/apps \
  -H "Content-Type: application/json" \
  -d '{"url": "https://github.com"}'
```

The server will automatically detect the app name and best available favicon.

---

## 📱 PWA Installation

1. Open the dashboard on your mobile device using your local network IP
2. **iOS:** Tap Share → "Add to Home Screen"
3. **Android:** Tap the browser menu → "Install App"
4. **Windows/Mac:** Click the install icon in the address bar

---

## 🎨 Design Principles

- **High-end minimalism** — Generous white space, bold clean typography
- **Monochrome palette** — Grays, deep blacks, off-whites
- **32px+ rounded corners** — Soft, modern card aesthetics
- **Fluid motion** — Subtle hover and transition animations
- **Responsive-first** — Mobile and desktop parity

---

## 📄 License

MIT © [Theus226File](https://github.com/Theus226File)